# GameOfLife-SPartial
A implementation of the main architecture of game of life in Scala.

-------------
Implementação do Game od Life em Scala. A primeira versão tem várias falhas de design.
Este projeto segue fielmente a arquitetura do @rbonifacio/gameOfLifeJ.
